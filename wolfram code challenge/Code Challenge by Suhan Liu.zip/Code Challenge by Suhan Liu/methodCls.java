import java.util.*;

public class methodCls{
	public boolean OddQ(int i){
		
		if(i % 2 == 0){
			
			return false;
		}else{
			return true;
		}
	}
	
	public char First(List<Character> list){
		
		return list.get(0);
		
	}
	
	public int modThree( int num){
		return num % 3;
	}
	
}
